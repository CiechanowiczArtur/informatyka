﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class Form1 : Form
    {
        bool paint = false;
        SolidBrush color;

        public Form1()
        {
            InitializeComponent();
        }

        private void btnExitClick(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnClearClick(object sender, EventArgs e)
        {
            Graphics g1 = panel1.CreateGraphics();
            g1.Clear(panel1.BackColor);
        }

        private void panel1_MouseUp(object sender, MouseEventArgs e)
        {
            paint = false;
        }

        private void panel1_MouseDown(object sender, MouseEventArgs e)
        {
            paint = true;
        }

        private void panel1_MouseMove(object sender, MouseEventArgs e)
        {
            if (paint)
            {
                color = new SolidBrush(Color.Black);
                Graphics g = panel1.CreateGraphics();
                g.FillEllipse(color, e.X, e.Y, 5, 5);
                g.Dispose();


            }

        }
    }
}
